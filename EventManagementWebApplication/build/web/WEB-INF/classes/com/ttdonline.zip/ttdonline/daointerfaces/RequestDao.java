package com.ttdonline.daointerfaces;

import com.ttdonline.beans.Request;
import java.sql.SQLException;
import java.util.List;

public interface RequestDao {
    public abstract void addRequest(Request r) throws SQLException,ClassNotFoundException;
//    public abstract void removeRequest(Request r) throws SQLException,ClassNotFoundException;
    public abstract String getRequestStatus(Request r) throws SQLException,ClassNotFoundException;
    public abstract List getRequests() throws SQLException,ClassNotFoundException;
}
